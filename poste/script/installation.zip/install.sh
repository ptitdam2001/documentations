#! /bin/bash
echo "Script d'installation fait pour chequesanté, si une erreur est remarquée, envoyer un mail: paul@chequesante.com"
echo "Le premier mot de passe demandé est le mot de passe à initialiser en tant que root pour la db mysql, les mots de passe demandés après sont le mot de passe session"
echo "appuyer sur la touche entrée pour commencer"
read -s UNUSED_VARIABLE

## Recupération et stockage temporaire dans la variable "PASSWD" du mot de passe de la DB mysql, en read caché

a=1
while [ $a = 1 ]
do
    echo "rentrer le mdp root de la db mysql"
    read -s PASSWD
    echo "rerentrer le mdp"
    read -s PASSWD2
    if [ $PASSWD = $PASSWD2 ]
	then
	echo "match"
	a=0
	else
	echo "les mots de passe ne correspondent pas"
    fi
done

## copie des fichiers temporaires dans /tmp

cp vhosts.conf /tmp/httpd-vhosts.conf
cp your_mac_user_name.conf /tmp/$USER.conf


## installation des différents éléments nécessaires pour le dev

ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
brew update
brew upgrade
brew tap homebrew/dupes
brew tap homebrew/versions
brew tap homebrew/homebrew-php
brew install --with-mcrypt --with-mysql php56
brew install php56-mcrypt
brew install mysql
brew install phpmyadmin

## creation du dossier Sites dans le home, vers lequel sont redirigés les virtualhosts

mkdir /Users/$USER/Sites
mkdir /Users/$USER/Sites/chequesante

## Création du fichier mysql.sock nécessaire au fonctionnement de mysql

touch /tmp/mysql.sock

## Modification de php.ini pour contenir la bonne timezone ainsi que les bonnes limites

sudo sed -i ".ini" 's:date.timezone =:date.timezone = "Europe/Paris":g' /usr/local/etc/php/5.6/php.ini
sudo sed -i ".ini" 's/upload_max_filesize = 2M/upload_max_filesize = 100M/g' /usr/local/etc/php/5.6/php.ini
sudo sed -i ".ini" 's/post_max_size = 8M/post_max_size = 100M/g' /usr/local/etc/php/5.6/php.ini

## Création de la db mysql dans le bon dossier

cd /usr/local/Cellar/mysql/*
mysql_install_db
mysql.server restart

## Linkage symbolique des fichiers .plist dans /Users/{nom d'utilisateur}/Library/LaunchAgents et démarrage des services

cd /Users/$USER
sudo ln -svf /usr/local/opt/mysql/*.plist ~/Library/LaunchAgents
sudo launchctl load ~/Library/LaunchAgents/homebrew.mxcl.mysql.plist

## Modification du mdp root de la db mysql avec le mdp stocké (PASSWD)

mysqladmin -u root password $PASSWD

## Modification des droits, puis du fichier /etc/hosts pour prendre en compte les différents domaines du site

sudo chmod ugo+w /etc/hosts
sudo echo "127.0.0.1 phpmyadmin.local praticien.local beneficiaire.local admin.local backoffice.local backadmin.local client.local api.local" >> /etc/hosts

## Creation du fichier utilisateur et mise en place dans /private/etc/apache2/users/

sed -i ".conf" "s:your_mac_user_name:$USER:g" "/tmp/$USER.conf"
sudo mv "/tmp/$USER.conf" /private/etc/apache2/users/

## Modification du fichier httpd.conf pour prendre en compte les hotes virtuels, le modules php5 et le mod_rewrite.

sudo chmod ug+w /private/etc/apache2/httpd.conf
cd /usr/local/Cellar/php56/5.6*/libexec/apache2/
sudo chmod ugo+rw /private/etc/apache2/httpd.conf
sudo sed -i ".conf" "s:#LoadModule php5_module libexec/apache2/libphp5.so:LoadModule php5_module `pwd`/libphp5.so:g" /private/etc/apache2/httpd.conf
sudo sed -i ".conf" 's:#LoadModule rewrite_module libexec/apache2/mod_rewrite.so:LoadModule rewrite_module libexec/apache2/mod_rewrite.so:g' /private/etc/apache2/httpd.conf
sudo sed -i ".conf" 's:#Include /private/etc/apache2/extra/httpd-vhosts.conf:Include /private/etc/apache2/extra/httpd-vhosts.conf:g' /private/etc/apache2/httpd.conf
cd ~/

## ajout des parametre user dans httpd.conf

sudo echo "Include /private/etc/apache2/users/*.conf" >> /private/etc/apache2/httpd.conf

## création du dossier "config" et modification de ses droits dans /usr/local/Cella/phpmyadmin/{version_phpmyadmin}/share/phpmyadmin

cd /usr/local/Cellar/phpmyadmin/*
cd share/phpmyadmin
sudo mkdir config
sudo chmod ugo+rw config
cd ~/

## configuration des vhosts

sudo chmod +w /private/etc/apache2/extra/httpd-vhosts.conf
sed -i ".conf" "s:montag_p:$USER:g" /tmp/httpd-vhosts.conf
sudo chmod ugo+r /tmp/httpd-vhosts.conf
sudo mv /tmp/httpd-vhosts.conf /private/etc/apache2/extra/

## Installation de zsh et oh-my-zsh pour un terminal plus ergonomique

brew install zsh zsh-completions
curl -L https://github.com/robbyrussell/oh-my-zsh/raw/master/tools/install.sh | sh

## Redemarrage de apache2

sudo apachectl restart
echo "Installation succeeded, you are ready to dev"
echo "The Game."
